# 🚌 Bus Register - Synology NAS Deployment Guide

## Complete Step-by-Step for Beginners

---

## 📋 What You Need

- ✅ Synology NAS with Container Manager installed
- ✅ Mac or PC with Docker Desktop installed
- ✅ The `nextjs_space` folder
- ✅ About 30-45 minutes

---

## 📁 STEP 1: Prepare Folders on Your NAS

### 1.1 Open File Station

Log into your Synology DSM web interface and open **File Station**.

### 1.2 Create Folders

1. Navigate to `docker` folder (create it if it doesn't exist)
2. Create folder: `bus-register`
3. Inside `bus-register`, create two folders:
   - `uploads`
   - `database`

**Final structure:**
```
volume1/
└── docker/
    └── bus-register/
        ├── uploads/     ← Student photos
        └── database/    ← PostgreSQL data
```

### 1.3 Set Permissions

1. Right-click `bus-register` folder → **Properties**
2. Go to **Permissions** tab
3. Click **Create**
4. Select **Everyone** → Check **Read** and **Write**
5. Check ✅ **Apply to this folder, sub-folders and files**
6. Click **OK** → **OK**

---

## 🐳 STEP 2: Build Docker Image on Your Computer

### 2.1 Fix the Prisma Schema (IMPORTANT!)

Open Terminal and run:

```bash
cd "/Users/jase/Documents/Docker Dev/bus_register/nextjs_space"

cat > prisma/schema.prisma << 'EOF'
generator client {
    provider = "prisma-client-js"
    binaryTargets = ["native", "linux-musl-openssl-3.0.x", "linux-musl-arm64-openssl-3.0.x"]
}

datasource db {
    provider = "postgresql"
    url      = env("DATABASE_URL")
}

model Student {
  id              String       @id @default(cuid())
  firstName       String
  lastName        String
  className       String
  photoUrl        String?
  photoKey        String?
  parentName      String?
  parentContact   String?
  dropOffLocation String?
  specialNotes    String?
  createdAt       DateTime     @default(now())
  updatedAt       DateTime     @updatedAt
  attendance      Attendance[]
}

model Attendance {
  id        String    @id @default(cuid())
  studentId String
  date      DateTime  @db.Date
  status    String    @default("absent")
  timestamp DateTime  @default(now())
  exitedAt  DateTime?
  student   Student   @relation(fields: [studentId], references: [id], onDelete: Cascade)

  @@unique([studentId, date])
  @@index([date])
}
EOF
```

### 2.2 Clear Docker Cache

```bash
docker builder prune -af
```

### 2.3 Build for Synology Architecture

**For Intel-based Synology (DS220+, DS720+, DS920+, DS1520+, etc.):**
```bash
docker build --platform linux/amd64 --no-cache -t bus-register:latest .
```

**For ARM-based Synology (DS220j, DS218, DS118, etc.):**
```bash
docker build --platform linux/arm64 --no-cache -t bus-register:latest .
```

⏱️ This takes 10-20 minutes. Wait for "Successfully built" message.

### 2.4 Save Image to File

```bash
docker save bus-register:latest -o bus-register.tar
```

### 2.5 Copy to Your NAS

Copy `bus-register.tar` to your NAS:
- Drag & drop into File Station, OR
- Copy via network share

Put it in: `/volume1/docker/bus-register/`

---

## 📦 STEP 3: Set Up Database Container

### 3.1 Open Container Manager

On your Synology DSM, open **Container Manager**.

### 3.2 Download PostgreSQL Image

1. Go to **Registry** tab
2. Search: `postgres`
3. Select `postgres` (official)
4. Click **Download**
5. Choose tag: **15**
6. Click **Select** and wait

### 3.3 Create Database Container

1. Go to **Container** tab → **Create**
2. Select `postgres:15` image → **Next**

**Container Name:**
```
bus-register-db
```
✅ Check "Enable auto-restart"

Click **Next**

**Port Settings:**

| Local Port | Container Port |
|------------|----------------|
| 5433 | 5432 |

*(Use 5433 if 5432 is already in use)*

Click **Next**

**Volume Settings:**

Click **Add Folder**:
1. Browse to: `docker` → `bus-register` → `database`
2. Click **Select**
3. In Mount path, type: `/var/lib/postgresql/data`

| Folder | Mount Path |
|--------|------------|
| /volume1/docker/bus-register/database | /var/lib/postgresql/data |

Click **Next**

**Environment Variables:**

Click **Add** for each:

| Variable | Value |
|----------|-------|
| POSTGRES_USER | busregister |
| POSTGRES_PASSWORD | BusRegister2026! |
| POSTGRES_DB | busregister |

Click **Next** → **Done**

✅ Database container will start automatically. Wait 30 seconds.

---

## 🌐 STEP 4: Set Up Web App Container

### 4.1 Import Bus Register Image

1. Go to **Image** tab
2. Click **Import** → **Add from file**
3. Browse to `/volume1/docker/bus-register/bus-register.tar`
4. Click **Select**
5. Wait for import (1-3 minutes)

### 4.2 Create Web App Container

1. Go to **Container** tab → **Create**
2. Select `bus-register:latest` → **Next**

**Container Name:**
```
bus-register-app
```
✅ Check "Enable auto-restart"

Click **Next**

**Port Settings:**

| Local Port | Container Port |
|------------|----------------|
| 3000 | 3000 |

Click **Next**

**Volume Settings:**

Click **Add Folder**:
1. Browse to: `docker` → `bus-register` → `uploads`
2. Click **Select**
3. In Mount path, type: `/app/uploads`

| Folder | Mount Path |
|--------|------------|
| /volume1/docker/bus-register/uploads | /app/uploads |

Click **Next**

**Environment Variables:**

Click **Add** for each:

| Variable | Value |
|----------|-------|
| DATABASE_URL | postgresql://busregister:BusRegister2026!@bus-register-db:5432/busregister |
| UPLOAD_DIR | /app/uploads |

⚠️ **Important:** `bus-register-db` in DATABASE_URL must match your database container name exactly!

Click **Next** → **Done**

---

## 🔧 STEP 5: Initialize Database

### 5.1 Open Container Terminal

1. In Container Manager, click on `bus-register-app`
2. Click **Action** → **Open terminal** (or **Details** → **Terminal**)
3. Click **Create**

### 5.2 Run Database Setup

In the terminal, type:

```bash
npx prisma db push
```

Press **Enter** and wait for:
```
✔ Your database is now in sync with your Prisma schema.
```

Close the terminal.

---

## 🎉 STEP 6: Access Your App!

### Find Your NAS IP

In DSM: **Control Panel** → **Network** → **Network Interface**

Look for your IP (e.g., `192.168.1.100`)

### Open the App

On any device on your network:

```
http://YOUR-NAS-IP:3000
```

Example: `http://192.168.1.100:3000`

🎊 **You should see the Bus Register dashboard!**

---

## 📱 iPad Setup

### Access on iPad

1. Open Safari
2. Go to `http://YOUR-NAS-IP:3000`

### Add to Home Screen

1. Tap the **Share** button (square with arrow)
2. Scroll down → **Add to Home Screen**
3. Name it "Bus Register"
4. Tap **Add**

Now you have an app icon! 📲

---

## 💾 Backup Your Data

| Data | Location |
|------|----------|
| Student Photos | /volume1/docker/bus-register/uploads |
| Database | /volume1/docker/bus-register/database |

Use **Hyper Backup** to schedule regular backups.

---

## 🔄 Updating the App

1. **On your Mac:**
   ```bash
   cd "/Users/jase/Documents/Docker Dev/bus_register/nextjs_space"
   docker builder prune -af
   docker build --platform linux/amd64 --no-cache -t bus-register:latest .
   docker save bus-register:latest -o bus-register.tar
   ```

2. Copy new `bus-register.tar` to NAS

3. **In Container Manager:**
   - Stop `bus-register-app` container
   - Go to **Image** → Delete old `bus-register:latest`
   - Import new `bus-register.tar`
   - Start `bus-register-app` container

✅ Your data is preserved!

---

## ❓ Troubleshooting

### "exec format error"
- Wrong architecture. Rebuild with `--platform linux/amd64` (Intel) or `--platform linux/arm64` (ARM)

### "Cannot connect to database"
- Check `bus-register-db` is running (green)
- Verify DATABASE_URL spelling exactly
- Make sure both containers are running

### "Module has no exported member"
- Prisma schema has wrong output path
- Re-run Step 2.1 to fix schema, then rebuild

### "Port already in use"
- Use different Local Port (e.g., 5433 instead of 5432)
- DATABASE_URL still uses internal port 5432

### "Photos not saving"
- Check uploads folder permissions
- Verify volume mount path is correct

---

## 📊 Quick Reference

| Item | Value |
|------|-------|
| App URL | http://YOUR-NAS-IP:3000 |
| App Container | bus-register-app |
| DB Container | bus-register-db |
| Photos Folder | /volume1/docker/bus-register/uploads |
| DB Folder | /volume1/docker/bus-register/database |
| DB Password | BusRegister2026! |
| DB Port (external) | 5433 |
| DB Port (internal) | 5432 |

---

**🎉 Congratulations!** Your Bus Register is running 100% locally on your Synology NAS!
