# 🚌 Bus Register - Synology Web Station Setup

## Simple Setup Without Docker

---

## 📋 What You Need

- ✅ Synology NAS with DSM 7.x
- ✅ Web Station installed
- ✅ Node.js package installed
- ✅ SSH access enabled

---

## 📦 STEP 1: Install Required Packages

### 1.1 Open Package Center

1. Log into DSM
2. Open **Package Center**

### 1.2 Install These Packages

Search and install:
1. **Web Station**
2. **Node.js v18** (or latest available)
3. **MariaDB 10** (we'll use this instead of PostgreSQL - simpler!)

---

## 🗄️ STEP 2: Set Up Database

### 2.1 Open MariaDB

1. Open **MariaDB 10** from main menu
2. Click **Reset root password** if first time
3. Set password: `BusRegister2026!`

### 2.2 Create Database via phpMyAdmin

1. Open **Web Station** → **phpMyAdmin** (or install it)
2. Or use SSH:

```bash
mysql -u root -p
```

Then run:
```sql
CREATE DATABASE busregister;
CREATE USER 'busregister'@'localhost' IDENTIFIED BY 'BusRegister2026!';
GRANT ALL PRIVILEGES ON busregister.* TO 'busregister'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

---

## 📁 STEP 3: Upload App Files

### 3.1 Create App Folder

1. Open **File Station**
2. Navigate to `web` folder
3. Create folder: `bus-register`

### 3.2 Upload Files

Upload the entire `nextjs_space` contents to `/volume1/web/bus-register/`

Your structure should be:
```
/volume1/web/bus-register/
├── app/
├── components/
├── lib/
├── prisma/
├── public/
├── package.json
├── next.config.js
└── ... other files
```

---

## ⚙️ STEP 4: Configure the App

### 4.1 Enable SSH

1. **Control Panel** → **Terminal & SNMP**
2. Check ✅ **Enable SSH service**
3. Click **Apply**

### 4.2 SSH into Your NAS

On your Mac:
```bash
ssh admin@YOUR-NAS-IP
```

Enter your DSM admin password.

### 4.3 Navigate to App Folder

```bash
cd /volume1/web/bus-register
```

### 4.4 Create Environment File

```bash
cat > .env << 'EOF'
DATABASE_URL="mysql://busregister:BusRegister2026!@localhost:3306/busregister"
UPLOAD_DIR="/volume1/web/bus-register/uploads"
EOF
```

### 4.5 Update Prisma for MySQL

```bash
cat > prisma/schema.prisma << 'EOF'
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "mysql"
  url      = env("DATABASE_URL")
}

model Student {
  id              String       @id @default(cuid())
  firstName       String
  lastName        String
  className       String
  photoUrl        String?
  photoKey        String?
  parentName      String?
  parentContact   String?
  dropOffLocation String?
  specialNotes    String?      @db.Text
  createdAt       DateTime     @default(now())
  updatedAt       DateTime     @updatedAt
  attendance      Attendance[]
}

model Attendance {
  id        String    @id @default(cuid())
  studentId String
  date      DateTime  @db.Date
  status    String    @default("absent")
  timestamp DateTime  @default(now())
  exitedAt  DateTime?
  student   Student   @relation(fields: [studentId], references: [id], onDelete: Cascade)

  @@unique([studentId, date])
  @@index([date])
  @@index([studentId])
}
EOF
```

### 4.6 Install Dependencies

```bash
npm install
```

### 4.7 Generate Prisma Client & Push Schema

```bash
npx prisma generate
npx prisma db push
```

### 4.8 Create Uploads Folder

```bash
mkdir -p uploads
chmod 777 uploads
```

### 4.9 Build the App

```bash
npm run build
```

---

## 🚀 STEP 5: Run the App

### 5.1 Install PM2 (Process Manager)

```bash
npm install -g pm2
```

### 5.2 Start the App

```bash
PORT=3000 pm2 start npm --name "bus-register" -- start
```

### 5.3 Make It Start on Boot

```bash
pm2 save
pm2 startup
```

Follow the command it gives you (copy/paste and run it).

---

## 🌐 STEP 6: Configure Web Station (Optional)

If you want to access via a nicer URL:

### 6.1 Set Up Reverse Proxy

1. Open **Control Panel** → **Login Portal** → **Advanced**
2. Click **Reverse Proxy** → **Create**
3. Configure:

| Setting | Value |
|---------|-------|
| Description | Bus Register |
| Source Protocol | HTTP |
| Source Hostname | * |
| Source Port | 80 (or 8080) |
| Destination Protocol | HTTP |
| Destination Hostname | localhost |
| Destination Port | 3000 |

4. Click **OK**

---

## 🎉 STEP 7: Access Your App!

### Direct Access
```
http://YOUR-NAS-IP:3000
```

### Via Reverse Proxy (if configured)
```
http://YOUR-NAS-IP
```

---

## 📱 iPad Setup

1. Open Safari on iPad
2. Go to `http://YOUR-NAS-IP:3000`
3. Tap Share → Add to Home Screen
4. Name it "Bus Register"

---

## 🔧 Useful Commands

### Check App Status
```bash
pm2 status
```

### View Logs
```bash
pm2 logs bus-register
```

### Restart App
```bash
pm2 restart bus-register
```

### Stop App
```bash
pm2 stop bus-register
```

---

## 📊 Quick Reference

| Item | Value |
|------|-------|
| App URL | http://YOUR-NAS-IP:3000 |
| App Location | /volume1/web/bus-register |
| Uploads | /volume1/web/bus-register/uploads |
| Database | MariaDB - busregister |
| DB Password | BusRegister2026! |

---

## ❓ Troubleshooting

### App won't start
```bash
cd /volume1/web/bus-register
pm2 logs bus-register
```

### Database connection error
- Check MariaDB is running in Package Center
- Verify DATABASE_URL in .env file

### Permission errors
```bash
chmod -R 755 /volume1/web/bus-register
chmod 777 /volume1/web/bus-register/uploads
```

### Rebuild after changes
```bash
cd /volume1/web/bus-register
npm run build
pm2 restart bus-register
```

---

**🎉 Done!** Your Bus Register is now running on Web Station!
