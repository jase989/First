"use client";

import { useState, useRef } from "react";
import { Camera, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import type { StudentData } from "@/lib/types";
import Image from "next/image";

interface StudentFormProps {
  student?: StudentData | null;
  onSubmit: (data: Partial<StudentData> & { photoFile?: File }) => Promise<void>;
  onCancel: () => void;
  isLoading?: boolean;
}

export function StudentForm({ student, onSubmit, onCancel, isLoading }: StudentFormProps) {
  const [firstName, setFirstName] = useState(student?.firstName ?? "");
  const [lastName, setLastName] = useState(student?.lastName ?? "");
  const [className, setClassName] = useState(student?.className ?? "");
  const [parentName, setParentName] = useState(student?.parentName ?? "");
  const [parentContact, setParentContact] = useState(student?.parentContact ?? "");
  const [dropOffLocation, setDropOffLocation] = useState(student?.dropOffLocation ?? "");
  const [specialNotes, setSpecialNotes] = useState(student?.specialNotes ?? "");
  const [photoPreview, setPhotoPreview] = useState<string | null>(student?.photoUrl ?? null);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e?.target?.files?.[0];
    if (file) {
      setPhotoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePhoto = () => {
    setPhotoFile(null);
    setPhotoPreview(null);
    if (fileInputRef?.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e?.preventDefault?.();
    await onSubmit?.({
      firstName,
      lastName,
      className,
      parentName,
      parentContact,
      dropOffLocation,
      specialNotes,
      photoFile: photoFile ?? undefined,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* Photo Upload */}
      <div className="flex flex-col items-center gap-4">
        <div className="relative">
          {photoPreview ? (
            <div className="relative w-24 h-24 rounded-full overflow-hidden border-4 border-amber-200 shadow-md">
              <Image
                src={photoPreview}
                alt="Student photo"
                fill
                className="object-cover"
              />
              <button
                type="button"
                onClick={handleRemovePhoto}
                className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-1 shadow-md hover:bg-red-600"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          ) : (
            <div
              onClick={() => fileInputRef?.current?.click?.()}
              className="w-24 h-24 rounded-full bg-gray-100 border-4 border-dashed border-gray-300 flex items-center justify-center cursor-pointer hover:border-amber-400 transition-colors"
            >
              <Camera className="h-8 w-8 text-gray-400" />
            </div>
          )}
        </div>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handlePhotoChange}
          className="hidden"
        />
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => fileInputRef?.current?.click?.()}
        >
          <Upload className="h-4 w-4 mr-1" />
          {photoPreview ? "Change Photo" : "Upload Photo"}
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="firstName">First Name *</Label>
          <Input
            id="firstName"
            value={firstName}
            onChange={(e) => setFirstName(e?.target?.value ?? "")}
            placeholder="Enter first name"
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="lastName">Last Name *</Label>
          <Input
            id="lastName"
            value={lastName}
            onChange={(e) => setLastName(e?.target?.value ?? "")}
            placeholder="Enter last name"
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="className">Class Name *</Label>
        <Input
          id="className"
          value={className}
          onChange={(e) => setClassName(e?.target?.value ?? "")}
          placeholder="e.g., Grade 5-A"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="parentName">Parent Name</Label>
        <Input
          id="parentName"
          value={parentName}
          onChange={(e) => setParentName(e?.target?.value ?? "")}
          placeholder="Parent or guardian name"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="parentContact">Parent Contact Details</Label>
        <Input
          id="parentContact"
          value={parentContact}
          onChange={(e) => setParentContact(e?.target?.value ?? "")}
          placeholder="Phone number or email"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="dropOffLocation">Home / Drop-off Location</Label>
        <Input
          id="dropOffLocation"
          value={dropOffLocation}
          onChange={(e) => setDropOffLocation(e?.target?.value ?? "")}
          placeholder="Student's drop-off location"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="specialNotes">Special Notes</Label>
        <Textarea
          id="specialNotes"
          value={specialNotes}
          onChange={(e) => setSpecialNotes(e?.target?.value ?? "")}
          placeholder="Any medical conditions, pickup instructions, etc."
          rows={3}
        />
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} disabled={isLoading}>
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading}>
          {isLoading ? "Saving..." : student ? "Update Student" : "Add Student"}
        </Button>
      </div>
    </form>
  );
}
