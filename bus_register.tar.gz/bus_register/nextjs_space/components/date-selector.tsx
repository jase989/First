"use client";

import { ChevronLeft, ChevronRight, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatDisplayDate, formatDate } from "@/lib/utils";

interface DateSelectorProps {
  selectedDate: string;
  onChange: (date: string) => void;
}

export function DateSelector({ selectedDate, onChange }: DateSelectorProps) {
  const handlePrevDay = () => {
    const date = new Date(selectedDate + "T12:00:00");
    date.setDate(date.getDate() - 1);
    onChange?.(formatDate(date));
  };

  const handleNextDay = () => {
    const date = new Date(selectedDate + "T12:00:00");
    date.setDate(date.getDate() + 1);
    onChange?.(formatDate(date));
  };

  const handleToday = () => {
    onChange?.(formatDate(new Date()));
  };

  const displayDate = formatDisplayDate(new Date(selectedDate + "T12:00:00"));

  return (
    <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-4">
      <div className="flex items-center gap-2">
        <Button variant="outline" size="icon" onClick={handlePrevDay}>
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <div className="flex items-center gap-2 min-w-[200px] sm:min-w-[280px] justify-center">
          <Calendar className="h-5 w-5 text-amber-600" />
          <span className="font-medium text-gray-900">{displayDate}</span>
        </div>
        <Button variant="outline" size="icon" onClick={handleNextDay}>
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
      <div className="flex items-center gap-2">
        <Button variant="secondary" size="sm" onClick={handleToday}>
          Today
        </Button>
        <input
          type="date"
          value={selectedDate}
          onChange={(e) => onChange?.(e?.target?.value ?? formatDate(new Date()))}
          className="h-9 px-3 rounded-md border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
        />
      </div>
    </div>
  );
}
