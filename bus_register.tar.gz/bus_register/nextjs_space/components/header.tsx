"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { Users, ClipboardCheck, FileText, LayoutDashboard } from "lucide-react";
import { cn } from "@/lib/utils";

export function Header() {
  const pathname = usePathname();

  const navItems = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/students", label: "Students", icon: Users },
    { href: "/attendance", label: "Attendance", icon: ClipboardCheck },
    { href: "/reports", label: "Reports", icon: FileText },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-amber-200 bg-amber-50/95 backdrop-blur supports-[backdrop-filter]:bg-amber-50/80">
      <div className="container max-w-6xl mx-auto px-4">
        {/* Top row: Logo */}
        <div className="flex h-14 items-center justify-center md:justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Image src="/favicon.png" alt="Bus Register" width={32} height={32} className="h-8 w-8" />
            <span className="font-bold text-xl text-gray-900">Bus Register</span>
          </Link>
          {/* Desktop navigation - hidden on mobile/tablet */}
          <nav className="hidden md:flex items-center gap-2">
            {(navItems ?? []).map((item) => {
              const Icon = item?.icon;
              const isActive = pathname === item?.href;
              return (
                <Link
                  key={item?.href ?? ""}
                  href={item?.href ?? "/"}
                  className={cn(
                    "flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium transition-colors",
                    isActive
                      ? "bg-amber-500 text-white shadow-md"
                      : "text-gray-700 hover:bg-amber-100"
                  )}
                >
                  {Icon && <Icon className="h-4 w-4" />}
                  <span>{item?.label ?? ""}</span>
                </Link>
              );
            })}
          </nav>
        </div>
        {/* Mobile/Tablet navigation row - always visible on smaller screens */}
        <nav className="flex md:hidden items-center justify-center gap-2 pb-3">
          {(navItems ?? []).map((item) => {
            const Icon = item?.icon;
            const isActive = pathname === item?.href;
            return (
              <Link
                key={item?.href ?? ""}
                href={item?.href ?? "/"}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors min-w-[70px] justify-center",
                  isActive
                    ? "bg-amber-500 text-white shadow-md"
                    : "text-gray-700 bg-amber-100/50 hover:bg-amber-100"
                )}
              >
                {Icon && <Icon className="h-5 w-5" />}
                <span className="text-xs">{item?.label ?? ""}</span>
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
