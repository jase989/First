"use client";

import { User, Phone, FileText, Pencil, Trash2, MapPin, UserCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { StudentData } from "@/lib/types";
import Image from "next/image";

interface StudentCardProps {
  student: StudentData;
  onEdit: (student: StudentData) => void;
  onDelete: (student: StudentData) => void;
}

export function StudentCard({ student, onEdit, onDelete }: StudentCardProps) {
  return (
    <Card className="hover:shadow-lg transition-shadow duration-200">
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          <div className="relative flex-shrink-0">
            {student?.photoUrl ? (
              <div className="relative w-16 h-16 rounded-full overflow-hidden border-2 border-amber-200">
                <Image
                  src={student.photoUrl}
                  alt={`${student?.firstName ?? ""} ${student?.lastName ?? ""}`}
                  fill
                  className="object-cover"
                />
              </div>
            ) : (
              <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center border-2 border-amber-200">
                <User className="h-8 w-8 text-amber-600" />
              </div>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-lg text-gray-900 truncate">
              {student?.firstName ?? ""} {student?.lastName ?? ""}
            </h3>
            <p className="text-sm text-amber-600 font-medium">{student?.className ?? ""}</p>
            {student?.parentName && (
              <div className="flex items-center gap-1 mt-1 text-sm text-gray-500">
                <UserCircle className="h-3 w-3" />
                <span className="truncate">{student.parentName}</span>
              </div>
            )}
            {student?.parentContact && (
              <div className="flex items-center gap-1 mt-1 text-sm text-gray-500">
                <Phone className="h-3 w-3" />
                <span className="truncate">{student.parentContact}</span>
              </div>
            )}
            {student?.dropOffLocation && (
              <div className="flex items-center gap-1 mt-1 text-sm text-gray-500">
                <MapPin className="h-3 w-3" />
                <span className="truncate">{student.dropOffLocation}</span>
              </div>
            )}
            {student?.specialNotes && (
              <div className="flex items-start gap-1 mt-1 text-sm text-gray-500">
                <FileText className="h-3 w-3 mt-0.5 flex-shrink-0" />
                <span className="line-clamp-2">{student.specialNotes}</span>
              </div>
            )}
          </div>
          <div className="flex flex-col gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onEdit?.(student)}
              className="h-8 w-8 text-gray-500 hover:text-amber-600"
            >
              <Pencil className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onDelete?.(student)}
              className="h-8 w-8 text-gray-500 hover:text-red-600"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
