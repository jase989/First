"use client";

import { User, Check, X, LogOut, MapPin } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { StudentData } from "@/lib/types";
import Image from "next/image";
import { cn } from "@/lib/utils";

interface AttendanceCardProps {
  student: StudentData;
  status: "present" | "absent" | "exited";
  exitedAt: string | null;
  onStatusChange: (studentId: string, status: "present" | "absent" | "exited") => void;
  disabled?: boolean;
}

export function AttendanceCard({ student, status, exitedAt, onStatusChange, disabled }: AttendanceCardProps) {
  const isPresent = status === "present";
  const isExited = status === "exited";
  const isAbsent = status === "absent";

  const getCardStyle = () => {
    if (isExited) return "border-blue-300 bg-blue-50";
    if (isPresent) return "border-green-300 bg-green-50";
    return "border-red-200 bg-red-50";
  };

  return (
    <Card className={cn("transition-all duration-200", getCardStyle())}>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className="relative flex-shrink-0">
            {student?.photoUrl ? (
              <div className="relative w-12 h-12 rounded-full overflow-hidden border-2 border-white shadow">
                <Image
                  src={student.photoUrl}
                  alt={`${student?.firstName ?? ""} ${student?.lastName ?? ""}`}
                  fill
                  className="object-cover"
                />
              </div>
            ) : (
              <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center border-2 border-gray-200 shadow">
                <User className="h-6 w-6 text-gray-400" />
              </div>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-medium text-gray-900 truncate">
              {student?.firstName ?? ""} {student?.lastName ?? ""}
            </h3>
            <p className="text-xs text-gray-500">{student?.className ?? ""}</p>
            {student?.dropOffLocation && (
              <div className="flex items-center gap-1 text-xs text-gray-400 mt-0.5">
                <MapPin className="h-3 w-3" />
                <span className="truncate">{student.dropOffLocation}</span>
              </div>
            )}
          </div>
          <div className="flex gap-1">
            <Button
              variant={isPresent ? "default" : "outline"}
              size="sm"
              onClick={() => onStatusChange?.(student?.id ?? "", "present")}
              disabled={disabled}
              className={cn(
                "h-9 w-9 p-0",
                isPresent && "bg-green-500 hover:bg-green-600"
              )}
              title="Present"
            >
              <Check className="h-4 w-4" />
            </Button>
            <Button
              variant={isAbsent ? "destructive" : "outline"}
              size="sm"
              onClick={() => onStatusChange?.(student?.id ?? "", "absent")}
              disabled={disabled}
              className="h-9 w-9 p-0"
              title="Absent"
            >
              <X className="h-4 w-4" />
            </Button>
            <Button
              variant={isExited ? "default" : "outline"}
              size="sm"
              onClick={() => onStatusChange?.(student?.id ?? "", "exited")}
              disabled={disabled}
              className={cn(
                "h-9 w-9 p-0",
                isExited && "bg-blue-500 hover:bg-blue-600"
              )}
              title="Exit Bus"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
        {isExited && exitedAt && (
          <p className="mt-2 text-xs text-blue-600 bg-white/50 rounded px-2 py-1">
            Exited at {new Date(exitedAt).toLocaleTimeString()}
          </p>
        )}
        {student?.specialNotes && (
          <p className="mt-2 text-xs text-gray-600 bg-white/50 rounded px-2 py-1">
            {student.specialNotes}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
