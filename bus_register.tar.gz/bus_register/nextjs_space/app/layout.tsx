import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Header } from "@/components/header";

const inter = Inter({ subsets: ["latin"] });

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Bus Register - Student Attendance Tracking",
  description: "Simple and efficient bus attendance tracking for school monitors",
  metadataBase: new URL(process.env.NEXTAUTH_URL ?? "http://localhost:3000"),
  icons: {
    icon: "/favicon.png",
    shortcut: "/favicon.png",
    apple: "/apple-touch-icon.png",
  },
  openGraph: {
    title: "Bus Register",
    description: "Simple and efficient bus attendance tracking for school monitors",
    images: ["/og-image.png"],
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script src="https://apps.abacus.ai/chatllm/appllm-lib.js"></script>
        <style dangerouslySetInnerHTML={{ __html: `[data-hydration-error] { display: none !important; }` }} />
      </head>
      <body className={`${inter.className} bg-gray-100 min-h-screen p-3 md:p-4`}>
        <div className="min-h-[calc(100vh-1.5rem)] md:min-h-[calc(100vh-2rem)] bg-gray-50 border-4 border-blue-900 rounded-2xl overflow-hidden shadow-lg">
          <Header />
          <main className="container max-w-6xl mx-auto px-4 py-6">
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}
