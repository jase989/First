"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { Users, ClipboardCheck, UserCheck, UserX, Calendar, FileText } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatDate, formatDisplayDate } from "@/lib/utils";
import type { StudentData } from "@/lib/types";

interface DailyStats {
  totalStudents: number;
  presentCount: number;
  absentCount: number;
}

export function DashboardClient() {
  const [currentDate, setCurrentDate] = useState<string>("");
  const [students, setStudents] = useState<StudentData[]>([]);
  const [stats, setStats] = useState<DailyStats>({ totalStudents: 0, presentCount: 0, absentCount: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const today = formatDate(new Date());
    setCurrentDate(today);
    fetchData(today);
  }, []);

  const fetchData = async (date: string) => {
    try {
      setLoading(true);
      const [studentsRes, reportRes] = await Promise.all([
        fetch("/api/students"),
        fetch(`/api/reports/daily?date=${date}`),
      ]);

      const studentsData = await studentsRes.json();
      const reportData = await reportRes.json();

      setStudents(studentsData ?? []);
      setStats({
        totalStudents: reportData?.totalStudents ?? 0,
        presentCount: reportData?.presentCount ?? 0,
        absentCount: reportData?.absentCount ?? 0,
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  const displayDate = currentDate ? formatDisplayDate(new Date(currentDate + "T12:00:00")) : "";

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="text-center py-8">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Image src="/favicon.png" alt="Bus Register" width={48} height={48} className="h-12 w-12" />
          <h1 className="text-4xl font-bold text-gray-900">Bus Register</h1>
        </div>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Track student attendance on the school bus quickly and efficiently.
          Mark attendance, manage students, and generate daily reports.
        </p>
      </div>

      {/* Date Display */}
      <div className="flex items-center justify-center gap-2 text-lg">
        <Calendar className="h-5 w-5 text-amber-600" />
        <span className="font-medium text-gray-700">{displayDate}</span>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="bg-white hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Students</CardTitle>
            <Users className="h-5 w-5 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900">
              {loading ? "..." : stats?.totalStudents ?? 0}
            </div>
            <p className="text-xs text-gray-500 mt-1">Registered on the bus</p>
          </CardContent>
        </Card>

        <Card className="bg-green-50 border-green-200 hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-green-700">Present Today</CardTitle>
            <UserCheck className="h-5 w-5 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-700">
              {loading ? "..." : stats?.presentCount ?? 0}
            </div>
            <p className="text-xs text-green-600 mt-1">Students on the bus</p>
          </CardContent>
        </Card>

        <Card className="bg-red-50 border-red-200 hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-red-700">Absent Today</CardTitle>
            <UserX className="h-5 w-5 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-700">
              {loading ? "..." : stats?.absentCount ?? 0}
            </div>
            <p className="text-xs text-red-600 mt-1">Students not on the bus</p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <Link href="/attendance" className="block">
          <Card className="h-full hover:shadow-lg transition-all hover:border-amber-300 cursor-pointer group">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <div className="h-16 w-16 rounded-full bg-amber-100 flex items-center justify-center mb-4 group-hover:bg-amber-200 transition-colors">
                <ClipboardCheck className="h-8 w-8 text-amber-600" />
              </div>
              <h3 className="font-semibold text-lg text-gray-900 mb-2">Take Attendance</h3>
              <p className="text-sm text-gray-500">Mark students as present or absent for today</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/students" className="block">
          <Card className="h-full hover:shadow-lg transition-all hover:border-amber-300 cursor-pointer group">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <div className="h-16 w-16 rounded-full bg-amber-100 flex items-center justify-center mb-4 group-hover:bg-amber-200 transition-colors">
                <Users className="h-8 w-8 text-amber-600" />
              </div>
              <h3 className="font-semibold text-lg text-gray-900 mb-2">Manage Students</h3>
              <p className="text-sm text-gray-500">Add, edit, or remove students from the register</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/reports" className="block sm:col-span-2 lg:col-span-1">
          <Card className="h-full hover:shadow-lg transition-all hover:border-amber-300 cursor-pointer group">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <div className="h-16 w-16 rounded-full bg-amber-100 flex items-center justify-center mb-4 group-hover:bg-amber-200 transition-colors">
                <FileText className="h-8 w-8 text-amber-600" />
              </div>
              <h3 className="font-semibold text-lg text-gray-900 mb-2">View Reports</h3>
              <p className="text-sm text-gray-500">Generate and download attendance reports</p>
            </CardContent>
          </Card>
        </Link>
      </div>

      {/* Recent Students */}
      {(students?.length ?? 0) > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-amber-500" />
              Registered Students
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
              {(students ?? []).slice(0, 10).map((student) => (
                <div
                  key={student?.id ?? ""}
                  className="text-center p-3 bg-gray-50 rounded-lg"
                >
                  <div className="w-10 h-10 mx-auto rounded-full bg-amber-100 flex items-center justify-center mb-2">
                    <span className="text-sm font-medium text-amber-700">
                      {student?.firstName?.[0] ?? ""}{student?.lastName?.[0] ?? ""}
                    </span>
                  </div>
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {student?.firstName ?? ""} {(student?.lastName ?? "")[0] ?? ""}.
                  </p>
                  <p className="text-xs text-gray-500">{student?.className ?? ""}</p>
                </div>
              ))}
            </div>
            {(students?.length ?? 0) > 10 && (
              <div className="text-center mt-4">
                <Link href="/students">
                  <Button variant="outline">
                    View all {students?.length ?? 0} students
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Empty State */}
      {!loading && (students?.length ?? 0) === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <Users className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No students registered yet</h3>
            <p className="text-gray-500 mb-4">Start by adding students to your bus register</p>
            <Link href="/students">
              <Button>Add Your First Student</Button>
            </Link>
          </CardContent>
        </Card>
      )}

      {/* Copyright Notice */}
      <div className="text-center py-8 mt-8 border-t border-gray-200">
        <p className="text-sm text-gray-500">Bus Register | Developed by Justin & Daddy | Privately Hosted by Synology Web Station | Abu Dhabi - 2026</p>
      </div>
    </div>
  );
}
