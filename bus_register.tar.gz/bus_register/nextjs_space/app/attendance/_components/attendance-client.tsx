"use client";

import { useState, useEffect, useCallback } from "react";
import { ClipboardCheck, Save, CheckCircle, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DateSelector } from "@/components/date-selector";
import { AttendanceCard } from "@/components/attendance-card";
import { formatDate, formatTime } from "@/lib/utils";
import type { StudentData } from "@/lib/types";
import Link from "next/link";

interface AttendanceState {
  [studentId: string]: {
    status: "present" | "absent" | "exited";
    timestamp: string | null;
    exitedAt: string | null;
  };
}

export function AttendanceClient() {
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [students, setStudents] = useState<StudentData[]>([]);
  const [attendance, setAttendance] = useState<AttendanceState>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<string | null>(null);
  const [hasChanges, setHasChanges] = useState(false);

  const fetchData = useCallback(async (date: string) => {
    try {
      setLoading(true);
      const [studentsRes, reportRes] = await Promise.all([
        fetch("/api/students"),
        fetch(`/api/reports/daily?date=${date}`),
      ]);

      const studentsData = await studentsRes.json();
      const reportData = await reportRes.json();

      setStudents(studentsData ?? []);

      // Build attendance state from report
      const attendanceMap: AttendanceState = {};
      (reportData?.records ?? []).forEach((record: { student: StudentData; status: string; timestamp: string | null; exitedAt: string | null }) => {
        attendanceMap[record?.student?.id ?? ""] = {
          status: (record?.status ?? "absent") as "present" | "absent" | "exited",
          timestamp: record?.timestamp ?? null,
          exitedAt: record?.exitedAt ?? null,
        };
      });
      setAttendance(attendanceMap);
      setHasChanges(false);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const today = formatDate(new Date());
    setSelectedDate(today);
  }, []);

  useEffect(() => {
    if (selectedDate) {
      fetchData(selectedDate);
    }
  }, [selectedDate, fetchData]);

  const handleStatusChange = (studentId: string, status: "present" | "absent" | "exited") => {
    setAttendance((prev) => ({
      ...(prev ?? {}),
      [studentId]: {
        status,
        timestamp: prev?.[studentId]?.timestamp ?? null,
        exitedAt: status === "exited" ? new Date().toISOString() : (prev?.[studentId]?.exitedAt ?? null),
      },
    }));
    setHasChanges(true);
  };

  const handleSave = async () => {
    try {
      setSaving(true);

      const records = (students ?? []).map((student) => ({
        studentId: student?.id ?? "",
        status: attendance?.[student?.id ?? ""]?.status ?? "absent",
        exitedAt: attendance?.[student?.id ?? ""]?.exitedAt ?? null,
      }));

      await fetch("/api/attendance/bulk", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          date: selectedDate,
          records,
        }),
      });

      setLastSaved(formatTime(new Date()));
      setHasChanges(false);
    } catch (error) {
      console.error("Error saving attendance:", error);
    } finally {
      setSaving(false);
    }
  };

  const presentCount = Object.values(attendance ?? {}).filter((a) => a?.status === "present")?.length ?? 0;
  const exitedCount = Object.values(attendance ?? {}).filter((a) => a?.status === "exited")?.length ?? 0;
  const absentCount = (students?.length ?? 0) - presentCount - exitedCount;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <ClipboardCheck className="h-7 w-7 text-amber-500" />
            Daily Attendance
          </h1>
          <p className="text-gray-600 mt-1">Mark students as present or absent</p>
        </div>
        <Button onClick={handleSave} disabled={saving || !hasChanges}>
          {saving ? (
            <>Saving...</>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              Save Attendance
            </>
          )}
        </Button>
      </div>

      {/* Date Selector */}
      <Card className="p-4">
        <DateSelector selectedDate={selectedDate} onChange={setSelectedDate} />
      </Card>

      {/* Stats & Last Saved */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2 flex-wrap">
          <div className="px-4 py-2 bg-green-100 rounded-lg">
            <span className="text-sm text-green-700 font-medium">
              Present: {presentCount}
            </span>
          </div>
          <div className="px-4 py-2 bg-blue-100 rounded-lg">
            <span className="text-sm text-blue-700 font-medium">
              Exited: {exitedCount}
            </span>
          </div>
          <div className="px-4 py-2 bg-red-100 rounded-lg">
            <span className="text-sm text-red-700 font-medium">
              Absent: {absentCount}
            </span>
          </div>
        </div>
        {lastSaved && (
          <div className="flex items-center gap-2 text-sm text-green-600">
            <CheckCircle className="h-4 w-4" />
            <span>Last saved at {lastSaved}</span>
          </div>
        )}
      </div>

      {/* Attendance Grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-gray-200" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-3/4" />
                    <div className="h-3 bg-gray-200 rounded w-1/2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (students?.length ?? 0) > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {(students ?? []).map((student) => (
            <AttendanceCard
              key={student?.id ?? ""}
              student={student}
              status={attendance?.[student?.id ?? ""]?.status ?? "absent"}
              exitedAt={attendance?.[student?.id ?? ""]?.exitedAt ?? null}
              onStatusChange={handleStatusChange}
              disabled={saving}
            />
          ))}
        </div>
      ) : (
        <Card className="text-center py-12">
          <CardContent>
            <Users className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              No students registered
            </h3>
            <p className="text-gray-500 mb-4">
              Add students first to start taking attendance
            </p>
            <Link href="/students">
              <Button>Add Students</Button>
            </Link>
          </CardContent>
        </Card>
      )}

      {/* Save Reminder */}
      {hasChanges && (students?.length ?? 0) > 0 && (
        <div className="fixed bottom-4 right-4 left-4 sm:left-auto sm:w-auto">
          <Card className="p-4 bg-amber-50 border-amber-300 shadow-lg">
            <div className="flex items-center justify-between gap-4">
              <span className="text-sm text-amber-800 font-medium">
                You have unsaved changes
              </span>
              <Button size="sm" onClick={handleSave} disabled={saving}>
                {saving ? "Saving..." : "Save Now"}
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
