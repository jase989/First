"use client";

import { useState, useEffect, useCallback } from "react";
import { FileText, Download, UserCheck, UserX, Clock, Users, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DateSelector } from "@/components/date-selector";
import { formatDate, formatDisplayDate, formatTime } from "@/lib/utils";
import type { StudentData } from "@/lib/types";
import Image from "next/image";
import Link from "next/link";

interface ReportRecord {
  student: StudentData;
  status: "present" | "absent" | "exited";
  timestamp: string | null;
  exitedAt: string | null;
}

interface DailyReport {
  date: string;
  totalStudents: number;
  presentCount: number;
  exitedCount: number;
  absentCount: number;
  records: ReportRecord[];
}

export function ReportsClient() {
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [report, setReport] = useState<DailyReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  const fetchReport = useCallback(async (date: string) => {
    try {
      setLoading(true);
      const res = await fetch(`/api/reports/daily?date=${date}`);
      const data = await res.json();
      setReport(data ?? null);
    } catch (error) {
      console.error("Error fetching report:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const today = formatDate(new Date());
    setSelectedDate(today);
  }, []);

  useEffect(() => {
    if (selectedDate) {
      fetchReport(selectedDate);
    }
  }, [selectedDate, fetchReport]);

  const generatePDF = async () => {
    try {
      setGenerating(true);

      // Dynamically import jspdf
      const { jsPDF } = await import("jspdf");
      const { default: autoTable } = await import("jspdf-autotable");

      const doc = new jsPDF();
      const displayDate = formatDisplayDate(new Date(selectedDate + "T12:00:00"));

      // Title
      doc.setFontSize(20);
      doc.setTextColor(245, 158, 11); // amber-500
      doc.text("Bus Register - Attendance Report", 105, 20, { align: "center" });

      // Date
      doc.setFontSize(14);
      doc.setTextColor(0, 0, 0);
      doc.text(`Date: ${displayDate}`, 105, 35, { align: "center" });

      // Generated timestamp
      doc.setFontSize(10);
      doc.setTextColor(100, 100, 100);
      doc.text(`Generated: ${new Date().toLocaleString()}`, 105, 45, { align: "center" });

      // Summary
      doc.setFontSize(12);
      doc.setTextColor(0, 0, 0);
      doc.text(`Total: ${report?.totalStudents ?? 0}`, 20, 60);
      doc.setTextColor(22, 163, 74); // green-600
      doc.text(`Present: ${report?.presentCount ?? 0}`, 55, 60);
      doc.setTextColor(59, 130, 246); // blue-500
      doc.text(`Exited: ${report?.exitedCount ?? 0}`, 100, 60);
      doc.setTextColor(220, 38, 38); // red-600
      doc.text(`Absent: ${report?.absentCount ?? 0}`, 145, 60);

      // Table data
      const tableData = (report?.records ?? []).map((record, index) => [
        String(index + 1),
        `${record?.student?.firstName ?? ""} ${record?.student?.lastName ?? ""}`,
        record?.student?.className ?? "",
        record?.student?.dropOffLocation ?? "-",
        (record?.status ?? "absent").toUpperCase(),
        record?.timestamp ? formatTime(record.timestamp) : "-",
        record?.exitedAt ? formatTime(record.exitedAt) : "-",
      ]);

      autoTable(doc, {
        head: [["#", "Student Name", "Class", "Drop-off", "Status", "Time In", "Time Out"]],
        body: tableData,
        startY: 70,
        styles: { fontSize: 9 },
        headStyles: { fillColor: [245, 158, 11] },
        alternateRowStyles: { fillColor: [255, 251, 235] },
        columnStyles: {
          0: { cellWidth: 10 },
          1: { cellWidth: 40 },
          2: { cellWidth: 25 },
          3: { cellWidth: 35 },
          4: { cellWidth: 22 },
          5: { cellWidth: 25 },
          6: { cellWidth: 25 },
        },
        didParseCell: function(data) {
          if (data?.section === "body" && data?.column?.index === 4) {
            const status = tableData?.[data?.row?.index]?.[4] ?? "ABSENT";
            if (status === "PRESENT") {
              data.cell.styles.textColor = [22, 163, 74];
            } else if (status === "EXITED") {
              data.cell.styles.textColor = [59, 130, 246];
            } else {
              data.cell.styles.textColor = [220, 38, 38];
            }
          }
        },
      });

      // Safari/iOS compatible PDF download
      const pdfBlob = doc.output("blob");
      const pdfUrl = URL.createObjectURL(pdfBlob);
      const fileName = `bus-attendance-${selectedDate}.pdf`;

      // Check if on iOS/Safari - use different approach
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
      const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);

      if (isIOS || isSafari) {
        // For Safari/iOS: Open PDF in new tab - user can then save from there
        const newWindow = window.open(pdfUrl, "_blank");
        if (!newWindow) {
          // If popup blocked, create download link
          const link = document.createElement("a");
          link.href = pdfUrl;
          link.download = fileName;
          link.target = "_blank";
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }
      } else {
        // For other browsers: Direct download
        const link = document.createElement("a");
        link.href = pdfUrl;
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }

      // Clean up blob URL after a delay
      setTimeout(() => URL.revokeObjectURL(pdfUrl), 1000);
    } catch (error) {
      console.error("Error generating PDF:", error);
    } finally {
      setGenerating(false);
    }
  };

  const displayDate = selectedDate ? formatDisplayDate(new Date(selectedDate + "T12:00:00")) : "";

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <FileText className="h-7 w-7 text-amber-500" />
            Attendance Reports
          </h1>
          <p className="text-gray-600 mt-1">View and download daily attendance reports</p>
        </div>
        <Button
          onClick={generatePDF}
          disabled={generating || loading || (report?.totalStudents ?? 0) === 0}
        >
          {generating ? (
            <>Generating...</>
          ) : (
            <>
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </>
          )}
        </Button>
      </div>

      {/* Date Selector */}
      <Card className="p-4">
        <DateSelector selectedDate={selectedDate} onChange={setSelectedDate} />
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total</CardTitle>
            <Users className="h-5 w-5 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">
              {loading ? "..." : report?.totalStudents ?? 0}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-green-50 border-green-200">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-green-700">Present</CardTitle>
            <UserCheck className="h-5 w-5 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-700">
              {loading ? "..." : report?.presentCount ?? 0}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-blue-50 border-blue-200">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-blue-700">Exited</CardTitle>
            <LogOut className="h-5 w-5 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-700">
              {loading ? "..." : report?.exitedCount ?? 0}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-red-50 border-red-200">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-red-700">Absent</CardTitle>
            <UserX className="h-5 w-5 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-700">
              {loading ? "..." : report?.absentCount ?? 0}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Report Table */}
      <Card>
        <CardHeader>
          <CardTitle>Attendance Record - {displayDate}</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="h-12 bg-gray-100 rounded animate-pulse" />
              ))}
            </div>
          ) : (report?.totalStudents ?? 0) > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-2 font-medium text-gray-600">#</th>
                    <th className="text-left py-3 px-2 font-medium text-gray-600">Student</th>
                    <th className="text-left py-3 px-2 font-medium text-gray-600">Class</th>
                    <th className="text-left py-3 px-2 font-medium text-gray-600">Drop-off</th>
                    <th className="text-left py-3 px-2 font-medium text-gray-600">Status</th>
                    <th className="text-left py-3 px-2 font-medium text-gray-600">Time In</th>
                    <th className="text-left py-3 px-2 font-medium text-gray-600">Time Out</th>
                  </tr>
                </thead>
                <tbody>
                  {(report?.records ?? []).map((record, index) => (
                    <tr
                      key={record?.student?.id ?? index}
                      className="border-b border-gray-100 hover:bg-gray-50"
                    >
                      <td className="py-3 px-2 text-gray-500">{index + 1}</td>
                      <td className="py-3 px-2">
                        <div className="flex items-center gap-2">
                          {record?.student?.photoUrl ? (
                            <div className="relative w-8 h-8 rounded-full overflow-hidden flex-shrink-0">
                              <Image
                                src={record.student.photoUrl}
                                alt=""
                                fill
                                className="object-cover"
                              />
                            </div>
                          ) : (
                            <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0">
                              <span className="text-xs font-medium text-amber-700">
                                {record?.student?.firstName?.[0] ?? ""}{record?.student?.lastName?.[0] ?? ""}
                              </span>
                            </div>
                          )}
                          <span className="font-medium text-gray-900 truncate">
                            {record?.student?.firstName ?? ""} {record?.student?.lastName ?? ""}
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-2 text-gray-600 text-sm">{record?.student?.className ?? ""}</td>
                      <td className="py-3 px-2 text-gray-500 text-sm truncate max-w-[120px]">{record?.student?.dropOffLocation ?? "-"}</td>
                      <td className="py-3 px-2">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                            record?.status === "present"
                              ? "bg-green-100 text-green-700"
                              : record?.status === "exited"
                              ? "bg-blue-100 text-blue-700"
                              : "bg-red-100 text-red-700"
                          }`}
                        >
                          {record?.status === "present" ? (
                            <UserCheck className="h-3 w-3" />
                          ) : record?.status === "exited" ? (
                            <LogOut className="h-3 w-3" />
                          ) : (
                            <UserX className="h-3 w-3" />
                          )}
                          {(record?.status ?? "absent").charAt(0).toUpperCase() + (record?.status ?? "absent").slice(1)}
                        </span>
                      </td>
                      <td className="py-3 px-2">
                        {record?.timestamp ? (
                          <span className="flex items-center gap-1 text-gray-500 text-sm">
                            <Clock className="h-3 w-3" />
                            {formatTime(record.timestamp)}
                          </span>
                        ) : (
                          <span className="text-gray-400 text-sm">-</span>
                        )}
                      </td>
                      <td className="py-3 px-2">
                        {record?.exitedAt ? (
                          <span className="flex items-center gap-1 text-blue-500 text-sm">
                            <LogOut className="h-3 w-3" />
                            {formatTime(record.exitedAt)}
                          </span>
                        ) : (
                          <span className="text-gray-400 text-sm">-</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-12">
              <Users className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-xl font-semibold text-gray-700 mb-2">
                No students registered
              </h3>
              <p className="text-gray-500 mb-4">
                Add students to generate attendance reports
              </p>
              <Link href="/students">
                <Button>Add Students</Button>
              </Link>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
