export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import type { Student } from "@prisma/client";

export async function GET() {
  try {
    const students = await prisma.student.findMany({
      orderBy: { lastName: "asc" },
    });

    const serializedStudents = (students ?? []).map((s: Student) => ({
      ...s,
      createdAt: s?.createdAt?.toISOString?.() ?? "",
      updatedAt: s?.updatedAt?.toISOString?.() ?? "",
    }));

    return NextResponse.json(serializedStudents);
  } catch (error) {
    console.error("Error fetching students:", error);
    return NextResponse.json(
      { error: "Failed to fetch students" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      firstName,
      lastName,
      className,
      photoUrl,
      photoKey,
      parentContact,
      specialNotes,
    } = body ?? {};

    if (!firstName || !lastName || !className) {
      return NextResponse.json(
        { error: "First name, last name, and class name are required" },
        { status: 400 }
      );
    }

    const student = await prisma.student.create({
      data: {
        firstName: firstName ?? "",
        lastName: lastName ?? "",
        className: className ?? "",
        photoUrl: photoUrl ?? null,
        photoKey: photoKey ?? null,
        parentContact: parentContact ?? null,
        specialNotes: specialNotes ?? null,
      },
    });

    return NextResponse.json({
      ...student,
      createdAt: student?.createdAt?.toISOString?.() ?? "",
      updatedAt: student?.updatedAt?.toISOString?.() ?? "",
    });
  } catch (error) {
    console.error("Error creating student:", error);
    return NextResponse.json(
      { error: "Failed to create student" },
      { status: 500 }
    );
  }
}
