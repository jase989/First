export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { deleteFile } from "@/lib/local-storage";

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params ?? {};
    const student = await prisma.student.findUnique({
      where: { id },
    });

    if (!student) {
      return NextResponse.json(
        { error: "Student not found" },
        { status: 404 }
      );
    }

    return NextResponse.json({
      ...student,
      createdAt: student?.createdAt?.toISOString?.() ?? "",
      updatedAt: student?.updatedAt?.toISOString?.() ?? "",
    });
  } catch (error) {
    console.error("Error fetching student:", error);
    return NextResponse.json(
      { error: "Failed to fetch student" },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params ?? {};
    const body = await request.json();
    const {
      firstName,
      lastName,
      className,
      photoUrl,
      photoKey,
      parentContact,
      specialNotes,
    } = body ?? {};

    // Get existing student to check for old photo
    const existingStudent = await prisma.student.findUnique({
      where: { id },
    });

    // Delete old photo if new one is being uploaded
    if (existingStudent?.photoKey && photoKey && existingStudent.photoKey !== photoKey) {
      try {
        await deleteFile(existingStudent.photoKey);
      } catch (err) {
        console.error("Error deleting old photo:", err);
      }
    }

    const student = await prisma.student.update({
      where: { id },
      data: {
        firstName: firstName ?? undefined,
        lastName: lastName ?? undefined,
        className: className ?? undefined,
        photoUrl: photoUrl !== undefined ? photoUrl : undefined,
        photoKey: photoKey !== undefined ? photoKey : undefined,
        parentContact: parentContact !== undefined ? parentContact : undefined,
        specialNotes: specialNotes !== undefined ? specialNotes : undefined,
      },
    });

    return NextResponse.json({
      ...student,
      createdAt: student?.createdAt?.toISOString?.() ?? "",
      updatedAt: student?.updatedAt?.toISOString?.() ?? "",
    });
  } catch (error) {
    console.error("Error updating student:", error);
    return NextResponse.json(
      { error: "Failed to update student" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params ?? {};

    // Get student to delete their photo
    const student = await prisma.student.findUnique({
      where: { id },
    });

    if (student?.photoKey) {
      try {
        await deleteFile(student.photoKey);
      } catch (err) {
        console.error("Error deleting photo:", err);
      }
    }

    await prisma.student.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting student:", error);
    return NextResponse.json(
      { error: "Failed to delete student" },
      { status: 500 }
    );
  }
}
