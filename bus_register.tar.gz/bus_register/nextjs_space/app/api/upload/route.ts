export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { saveFile, getFileUrl } from "@/lib/local-storage";

export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return NextResponse.json(
        { error: "No file provided" },
        { status: 400 }
      );
    }

    // Convert file to buffer
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    // Save file locally
    const storagePath = await saveFile(file.name, buffer);
    const fileUrl = getFileUrl(storagePath);

    return NextResponse.json({ 
      storagePath, 
      fileUrl,
      fileName: file.name,
      size: file.size 
    });
  } catch (error) {
    console.error("Error uploading file:", error);
    return NextResponse.json(
      { error: "Failed to upload file" },
      { status: 500 }
    );
  }
}
