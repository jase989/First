export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import type { Attendance, Student } from "@prisma/client";

type AttendanceWithStudent = Attendance & { student: Student };

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request?.url ?? "");
    const dateStr = searchParams?.get?.("date");
    const attendanceType = searchParams?.get?.("type") ?? "daily";

    if (!dateStr) {
      return NextResponse.json(
        { error: "Date parameter is required" },
        { status: 400 }
      );
    }

    const date = new Date(dateStr + "T00:00:00.000Z");

    // Get all students
    const students = await prisma.student.findMany({
      orderBy: { lastName: "asc" },
    });

    // Get attendance for the date and type
    const attendance = await prisma.attendance.findMany({
      where: { date, attendanceType },
      include: { student: true },
    });

    const attendanceMap = new Map<string, AttendanceWithStudent>();
    (attendance ?? []).forEach((a: AttendanceWithStudent) => {
      attendanceMap.set(a?.studentId ?? "", a);
    });

    // Combine students with attendance
    const records = (students ?? []).map((student: Student) => {
      const record = attendanceMap?.get?.(student?.id ?? "");
      return {
        student: {
          ...student,
          createdAt: student?.createdAt?.toISOString?.() ?? "",
          updatedAt: student?.updatedAt?.toISOString?.() ?? "",
        },
        status: record?.status ?? "absent",
        timestamp: record?.timestamp?.toISOString?.() ?? null,
        exitedAt: record?.exitedAt?.toISOString?.() ?? null,
      };
    });

    const presentCount = records?.filter?.((r: { status: string }) => r?.status === "present")?.length ?? 0;
    const exitedCount = records?.filter?.((r: { status: string }) => r?.status === "exited")?.length ?? 0;

    return NextResponse.json({
      date: dateStr,
      attendanceType,
      totalStudents: students?.length ?? 0,
      presentCount,
      exitedCount,
      absentCount: (students?.length ?? 0) - presentCount - exitedCount,
      records,
    });
  } catch (error) {
    console.error("Error generating report:", error);
    return NextResponse.json(
      { error: "Failed to generate report" },
      { status: 500 }
    );
  }
}
