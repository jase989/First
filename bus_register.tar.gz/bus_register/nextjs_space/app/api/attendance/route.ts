export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import type { Attendance, Student } from "@prisma/client";

type AttendanceWithStudent = Attendance & { student: Student };

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request?.url ?? "");
    const dateStr = searchParams?.get?.("date");

    if (!dateStr) {
      return NextResponse.json(
        { error: "Date parameter is required" },
        { status: 400 }
      );
    }

    const date = new Date(dateStr + "T00:00:00.000Z");

    const attendance = await prisma.attendance.findMany({
      where: { date },
      include: { student: true },
      orderBy: { student: { lastName: "asc" } },
    });

    const serializedAttendance = (attendance ?? []).map((a: AttendanceWithStudent) => ({
      ...a,
      date: a?.date?.toISOString?.()?.split?.("T")?.[0] ?? "",
      timestamp: a?.timestamp?.toISOString?.() ?? "",
      student: a?.student
        ? {
            ...a.student,
            createdAt: a?.student?.createdAt?.toISOString?.() ?? "",
            updatedAt: a?.student?.updatedAt?.toISOString?.() ?? "",
          }
        : null,
    }));

    return NextResponse.json(serializedAttendance);
  } catch (error) {
    console.error("Error fetching attendance:", error);
    return NextResponse.json(
      { error: "Failed to fetch attendance" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { studentId, date, status } = body ?? {};

    if (!studentId || !date || !status) {
      return NextResponse.json(
        { error: "studentId, date, and status are required" },
        { status: 400 }
      );
    }

    const dateObj = new Date(date + "T00:00:00.000Z");

    const attendance = await prisma.attendance.upsert({
      where: {
        studentId_date: {
          studentId,
          date: dateObj,
        },
      },
      create: {
        studentId,
        date: dateObj,
        status,
        timestamp: new Date(),
      },
      update: {
        status,
        timestamp: new Date(),
      },
      include: { student: true },
    });

    return NextResponse.json({
      ...attendance,
      date: attendance?.date?.toISOString?.()?.split?.("T")?.[0] ?? "",
      timestamp: attendance?.timestamp?.toISOString?.() ?? "",
      student: attendance?.student
        ? {
            ...attendance.student,
            createdAt: attendance?.student?.createdAt?.toISOString?.() ?? "",
            updatedAt: attendance?.student?.updatedAt?.toISOString?.() ?? "",
          }
        : null,
    });
  } catch (error) {
    console.error("Error saving attendance:", error);
    return NextResponse.json(
      { error: "Failed to save attendance" },
      { status: 500 }
    );
  }
}
