export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { date, records, attendanceType = "daily" } = body ?? {};

    if (!date || !records || !Array.isArray(records)) {
      return NextResponse.json(
        { error: "date and records array are required" },
        { status: 400 }
      );
    }

    const dateObj = new Date(date + "T00:00:00.000Z");

    const results = await Promise.all(
      (records ?? []).map(async (record: { studentId: string; status: string; exitedAt?: string | null }) => {
        const exitedAtDate = record?.exitedAt ? new Date(record.exitedAt) : null;
        return prisma.attendance.upsert({
          where: {
            studentId_date_attendanceType: {
              studentId: record?.studentId ?? "",
              date: dateObj,
              attendanceType,
            },
          },
          create: {
            studentId: record?.studentId ?? "",
            date: dateObj,
            attendanceType,
            status: record?.status ?? "absent",
            timestamp: new Date(),
            exitedAt: exitedAtDate,
          },
          update: {
            status: record?.status ?? "absent",
            timestamp: new Date(),
            exitedAt: exitedAtDate,
          },
        });
      })
    );

    return NextResponse.json({ success: true, count: results?.length ?? 0 });
  } catch (error) {
    console.error("Error saving bulk attendance:", error);
    return NextResponse.json(
      { error: "Failed to save attendance" },
      { status: 500 }
    );
  }
}
