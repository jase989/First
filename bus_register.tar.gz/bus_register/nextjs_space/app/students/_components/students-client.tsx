"use client";

import { useState, useEffect } from "react";
import { Plus, Search, Users, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { StudentCard } from "@/components/student-card";
import { StudentForm } from "@/components/student-form";
import type { StudentData } from "@/lib/types";

export function StudentsClient() {
  const [students, setStudents] = useState<StudentData[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<StudentData | null>(null);
  const [formLoading, setFormLoading] = useState(false);

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/students");
      const data = await res.json();
      setStudents(data ?? []);
    } catch (error) {
      console.error("Error fetching students:", error);
    } finally {
      setLoading(false);
    }
  };

  const uploadPhoto = async (file: File): Promise<{ url: string; key: string } | null> => {
    try {
      // Upload file directly to local storage
      const formData = new FormData();
      formData.append('file', file);

      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!res.ok) {
        throw new Error("Upload failed");
      }

      const { storagePath, fileUrl } = await res.json();

      return { url: fileUrl, key: storagePath };
    } catch (error) {
      console.error("Error uploading photo:", error);
      return null;
    }
  };

  const handleSubmit = async (data: Partial<StudentData> & { photoFile?: File }) => {
    try {
      setFormLoading(true);

      let photoUrl = selectedStudent?.photoUrl ?? null;
      let photoKey = selectedStudent?.photoKey ?? null;

      // Upload photo if provided
      if (data.photoFile) {
        const uploadResult = await uploadPhoto(data.photoFile);
        if (uploadResult) {
          photoUrl = uploadResult.url;
          photoKey = uploadResult.key;
        }
      }

      const payload = {
        firstName: data?.firstName ?? "",
        lastName: data?.lastName ?? "",
        className: data?.className ?? "",
        parentContact: data?.parentContact ?? "",
        specialNotes: data?.specialNotes ?? "",
        photoUrl,
        photoKey,
      };

      if (selectedStudent) {
        // Update existing student
        await fetch(`/api/students/${selectedStudent.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      } else {
        // Create new student
        await fetch("/api/students", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      }

      await fetchStudents();
      setIsFormOpen(false);
      setSelectedStudent(null);
    } catch (error) {
      console.error("Error saving student:", error);
    } finally {
      setFormLoading(false);
    }
  };

  const handleEdit = (student: StudentData) => {
    setSelectedStudent(student);
    setIsFormOpen(true);
  };

  const handleDelete = async () => {
    if (!selectedStudent) return;

    try {
      await fetch(`/api/students/${selectedStudent.id}`, {
        method: "DELETE",
      });
      await fetchStudents();
      setIsDeleteOpen(false);
      setSelectedStudent(null);
    } catch (error) {
      console.error("Error deleting student:", error);
    }
  };

  const openDeleteDialog = (student: StudentData) => {
    setSelectedStudent(student);
    setIsDeleteOpen(true);
  };

  const filteredStudents = (students ?? []).filter((student) => {
    const query = (searchQuery ?? "").toLowerCase();
    const fullName = `${student?.firstName ?? ""} ${student?.lastName ?? ""}`.toLowerCase();
    const className = (student?.className ?? "").toLowerCase();
    return fullName?.includes?.(query) || className?.includes?.(query);
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Users className="h-7 w-7 text-amber-500" />
            Student Management
          </h1>
          <p className="text-gray-600 mt-1">Add and manage students on the bus register</p>
        </div>
        <Button onClick={() => { setSelectedStudent(null); setIsFormOpen(true); }}>
          <Plus className="h-4 w-4 mr-2" />
          Add Student
        </Button>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
        <Input
          placeholder="Search students by name or class..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e?.target?.value ?? "")}
          className="pl-10"
        />
      </div>

      {/* Student List */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <div className="w-16 h-16 rounded-full bg-gray-200" />
                  <div className="flex-1 space-y-2">
                    <div className="h-5 bg-gray-200 rounded w-3/4" />
                    <div className="h-4 bg-gray-200 rounded w-1/2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (filteredStudents?.length ?? 0) > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {(filteredStudents ?? []).map((student) => (
            <StudentCard
              key={student?.id ?? ""}
              student={student}
              onEdit={handleEdit}
              onDelete={openDeleteDialog}
            />
          ))}
        </div>
      ) : (
        <Card className="text-center py-12">
          <CardContent>
            <Users className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              {searchQuery ? "No students found" : "No students registered"}
            </h3>
            <p className="text-gray-500 mb-4">
              {searchQuery
                ? "Try adjusting your search query"
                : "Get started by adding your first student"}
            </p>
            {!searchQuery && (
              <Button onClick={() => setIsFormOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Student
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Add/Edit Form Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {selectedStudent ? "Edit Student" : "Add New Student"}
            </DialogTitle>
            <DialogDescription>
              {selectedStudent
                ? "Update the student information below"
                : "Fill in the details to add a new student to the bus register"}
            </DialogDescription>
          </DialogHeader>
          <StudentForm
            student={selectedStudent}
            onSubmit={handleSubmit}
            onCancel={() => {
              setIsFormOpen(false);
              setSelectedStudent(null);
            }}
            isLoading={formLoading}
          />
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="h-5 w-5" />
              Delete Student
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to delete{" "}
              <span className="font-semibold">
                {selectedStudent?.firstName ?? ""} {selectedStudent?.lastName ?? ""}
              </span>
              ? This action cannot be undone and will also delete their attendance records.
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2 mt-4">
            <Button variant="outline" onClick={() => setIsDeleteOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              Delete
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
