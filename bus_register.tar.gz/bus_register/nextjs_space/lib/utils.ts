import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d?.toISOString?.()?.split?.("T")?.[0] ?? "";
}

export function formatDisplayDate(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d?.toLocaleDateString?.("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  }) ?? "";
}

export function formatTime(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d?.toLocaleTimeString?.("en-US", {
    hour: "2-digit",
    minute: "2-digit",
  }) ?? "";
}
