export interface StudentData {
  id: string;
  firstName: string;
  lastName: string;
  className: string;
  photoUrl: string | null;
  photoKey: string | null;
  parentName: string | null;
  parentContact: string | null;
  dropOffLocation: string | null;
  specialNotes: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  date: string;
  status: "present" | "absent" | "exited";
  timestamp: string;
  exitedAt: string | null;
  student?: StudentData;
}

export interface AttendanceWithStudent extends AttendanceRecord {
  student: StudentData;
}

export interface DailyReport {
  date: string;
  totalStudents: number;
  presentCount: number;
  absentCount: number;
  exitedCount: number;
  records: AttendanceWithStudent[];
}
