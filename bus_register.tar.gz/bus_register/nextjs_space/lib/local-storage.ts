import fs from 'fs';
import path from 'path';

// Upload directory - this will be mapped to Synology shared folder via Docker volume
const UPLOAD_DIR = process.env.UPLOAD_DIR || './uploads';

export function ensureUploadDir(): void {
  const uploadPath = path.resolve(UPLOAD_DIR);
  if (!fs.existsSync(uploadPath)) {
    fs.mkdirSync(uploadPath, { recursive: true });
  }
}

export function generateFilePath(fileName: string): string {
  const timestamp = Date.now();
  const sanitizedName = fileName.replace(/[^a-zA-Z0-9.-]/g, '_');
  return `${timestamp}-${sanitizedName}`;
}

export function getUploadDir(): string {
  return path.resolve(UPLOAD_DIR);
}

export async function saveFile(fileName: string, buffer: Buffer): Promise<string> {
  ensureUploadDir();
  const storagePath = generateFilePath(fileName);
  const fullPath = path.join(getUploadDir(), storagePath);
  
  await fs.promises.writeFile(fullPath, buffer);
  
  return storagePath;
}

export async function deleteFile(storagePath: string): Promise<void> {
  const fullPath = path.join(getUploadDir(), storagePath);
  
  if (fs.existsSync(fullPath)) {
    await fs.promises.unlink(fullPath);
  }
}

export function getFileUrl(storagePath: string): string {
  // Returns the API route to serve the file
  return `/api/uploads/${storagePath}`;
}

export async function getFile(storagePath: string): Promise<Buffer | null> {
  const fullPath = path.join(getUploadDir(), storagePath);
  
  if (!fs.existsSync(fullPath)) {
    return null;
  }
  
  return fs.promises.readFile(fullPath);
}
